﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Suma de dos numeros enteros");

var numero1 = 5;

var numero2 = 7;

Console.WriteLine("Por favor, ingresa la suma de " + numero1 + " y " + numero2 + ": ");

var respuesta = Console.ReadLine();

var resultado = Convert.ToInt32(respuesta);

var esCorrecto = resultado == (numero1 + numero2); 

Console.WriteLine("Tu respuesta es " + esCorrecto);
