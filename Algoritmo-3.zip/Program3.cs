﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Verificación de un número");

var numero = 42;

Console.WriteLine("Por favor, ingresa el número " + numero + ": ");

var respuesta = Console.ReadLine();

var numeroIngresado = Convert.ToInt32(respuesta);

var esCorrecto = numeroIngresado == numero;

Console.WriteLine("Tu respuesta es: " + esCorrecto);