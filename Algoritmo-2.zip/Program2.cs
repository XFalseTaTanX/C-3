﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Doble de un número");

var numero = 7;

Console.WriteLine("Por favor, ingresa el doble de " + numero + ": ");

var respuesta = Console.ReadLine();

var resultado = Convert.ToInt32(respuesta);

var esCorrecto = resultado == (numero * 2);

Console.WriteLine("Tu respuesta es. " + esCorrecto);