﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine(" Usando una constante");

const double PI = 3.14159265359;

double radio = 5.0; double area = PI * radio * radio;

Console.WriteLine("El valor de PI es constante: " + PI);

Console.WriteLine("Dado un radio de " + radio + " unidades,");

Console.WriteLine("El área de un círculo es: " + area + " unidades cuadradas.");
