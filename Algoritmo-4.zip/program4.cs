﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Incremento y decremento");

var numero = 10;

Console.WriteLine("El valor inicial es " + numero);

numero++;

Console.WriteLine("Después de incrementar, el valor es " + numero);

numero--;

Console.WriteLine("Después de decrementar, el valor es: " + numero);
